
public class FirstPGM
{

	public static void main(String[] args)
	{
		int score;//this is a named memory location called score of data type int
		score = 12;
		System.out.println("score has the value " + score);
		double value1 = 22.99, value2 = 76.554;
		double answer = value1 + value2;
		System.out.println(value1 + " + " + value2 + " = " + answer);
	}

}
