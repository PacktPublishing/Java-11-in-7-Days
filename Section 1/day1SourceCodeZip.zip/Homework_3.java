
public class Homework_3
{
	public static void main(String[] args)
	{
		double F = 32;
		double C = 32;
		double answer = 0.0;
		
		answer = (F - 32) * (5.0/9.0);
		System.out.println(F + " degrees Fahrenheit = " + answer + " degress Celsius");
		
		answer = ((C * (9.0/5.0)) + 32);
		System.out.println(C + " degrees Celsius = " + answer + " degress Fahrenheit");
		
	}
}
