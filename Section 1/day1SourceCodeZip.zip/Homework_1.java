
public class Homework_1
{

	public static void main(String[] args)
	{
		System.out.println("+----------------------------+");
		System.out.println("|    1. Games                |");
		System.out.println("|    2. Home Video Collection|");
		System.out.println("|    3. Flight Plans         |");
		System.out.println("|    4. Work Documents       |");
		System.out.println("|    5. Exit                 |");
		System.out.println("+----------------------------+");
	}

}
