package video2Day7;

public class CircleException extends Exception
{
	//Constructor
	public CircleException(String message)
	{
		super(message);
	}	
}
