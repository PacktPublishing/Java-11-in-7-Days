package packt.shape;

public class Test2DShape
{
	public static void main(String[] args)
	{
		/*TwoDShape shape1 = new TwoDShape(10, 12);
		int x = shape1.getXPos();
		int y = shape1.getYPos();
		System.out.println("shape1 x pos = " + x);
		System.out.println("shape1 y pos = " + y);
		shape1.setXPos(99);
		shape1.setYPos(0);
		System.out.println("shape1 x pos = " + x);
		System.out.println("shape1 y pos = " + y);
		System.out.println(shape1.toString());*/
	}
}
