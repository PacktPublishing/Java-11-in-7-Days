package packt.shape;

public interface DrawShape
{
	public static final int ZOOM_PLUS = 1;
	public static final int ZOOM_MINUS = -1;
	
	public abstract void draw( );
}
